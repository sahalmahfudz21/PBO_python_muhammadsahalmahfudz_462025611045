# ============================================================
#   database.py — Database Layer (SQLite)
#   Sistem Pemesanan Tiket Kereta Api
# ============================================================

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "kereta.db")


def get_connection():
    """Mengembalikan koneksi SQLite ke file database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row   # akses kolom dengan nama
    return conn


def inisialisasi_database():
    """
    Membuat semua tabel jika belum ada dan mengisi data awal kereta.
    Dipanggil sekali saat aplikasi pertama kali dijalankan.
    """
    conn = get_connection()
    cur = conn.cursor()

    # ----------------------------------------------------------
    # DDL — Create Tables
    # ----------------------------------------------------------
    cur.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS kereta (
            id_kereta   INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_kereta TEXT    NOT NULL,
            kode_kereta TEXT    NOT NULL UNIQUE,
            asal        TEXT    NOT NULL,
            tujuan      TEXT    NOT NULL,
            jam_berangkat TEXT  NOT NULL,
            jam_tiba    TEXT    NOT NULL
        );

        CREATE TABLE IF NOT EXISTS kelas_kereta (
            id_kelas    INTEGER PRIMARY KEY AUTOINCREMENT,
            id_kereta   INTEGER NOT NULL REFERENCES kereta(id_kereta),
            nama_kelas  TEXT    NOT NULL,   -- Ekonomi / Bisnis / Eksekutif
            harga       REAL    NOT NULL,
            total_kursi INTEGER NOT NULL,
            sisa_kursi  INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS penumpang (
            id_penumpang INTEGER PRIMARY KEY AUTOINCREMENT,
            nama         TEXT NOT NULL,
            nik          TEXT NOT NULL UNIQUE,
            email        TEXT,
            telepon      TEXT
        );

        CREATE TABLE IF NOT EXISTS pemesanan (
            id_pemesanan   INTEGER PRIMARY KEY AUTOINCREMENT,
            kode_booking   TEXT    NOT NULL UNIQUE,
            id_penumpang   INTEGER NOT NULL REFERENCES penumpang(id_penumpang),
            id_kelas       INTEGER NOT NULL REFERENCES kelas_kereta(id_kelas),
            jumlah_tiket   INTEGER NOT NULL DEFAULT 1,
            total_harga    REAL    NOT NULL,
            status         TEXT    NOT NULL DEFAULT 'PENDING',  -- PENDING/LUNAS/BATAL
            tanggal_pesan  TEXT    NOT NULL,
            tanggal_berangkat TEXT NOT NULL
        );
    """)

    # ----------------------------------------------------------
    # DML — Seed data kereta (hanya jika tabel masih kosong)
    # ----------------------------------------------------------
    cur.execute("SELECT COUNT(*) FROM kereta")
    if cur.fetchone()[0] == 0:
        kereta_list = [
            ("Argo Bromo Anggrek", "ABA", "Jakarta Gambir", "Surabaya Pasar Turi", "08:00", "17:30"),
            ("Bima",               "BIM", "Jakarta Gambir", "Surabaya Gubeng",      "17:00", "05:30"),
            ("Gajayana",           "GAJ", "Jakarta Gambir", "Malang",               "17:45", "07:00"),
            ("Lodaya",             "LOD", "Bandung",        "Solo Balapan",         "08:10", "16:15"),
            ("Taksaka",            "TAK", "Jakarta Gambir", "Yogyakarta",           "10:00", "17:00"),
        ]
        cur.executemany(
            "INSERT INTO kereta (nama_kereta,kode_kereta,asal,tujuan,jam_berangkat,jam_tiba) "
            "VALUES (?,?,?,?,?,?)",
            kereta_list
        )

        # Kelas untuk setiap kereta
        kelas_data = []
        cur.execute("SELECT id_kereta FROM kereta ORDER BY id_kereta")
        ids = [r[0] for r in cur.fetchall()]
        for id_k in ids:
            kelas_data += [
                (id_k, "Ekonomi",   250_000, 80, 80),
                (id_k, "Bisnis",    400_000, 50, 50),
                (id_k, "Eksekutif", 650_000, 30, 30),
            ]
        cur.executemany(
            "INSERT INTO kelas_kereta (id_kereta,nama_kelas,harga,total_kursi,sisa_kursi) "
            "VALUES (?,?,?,?,?)",
            kelas_data
        )

    conn.commit()
    conn.close()
    print("[DB] Database siap digunakan.")


# ----------------------------------------------------------
# Helper queries
# ----------------------------------------------------------

def ambil_semua_kereta():
    conn = get_connection()
    rows = conn.execute("""
        SELECT k.id_kereta, k.nama_kereta, k.kode_kereta,
               k.asal, k.tujuan, k.jam_berangkat, k.jam_tiba
        FROM kereta k
        ORDER BY k.id_kereta
    """).fetchall()
    conn.close()
    return rows


def ambil_kelas_by_kereta(id_kereta: int):
    conn = get_connection()
    rows = conn.execute("""
        SELECT id_kelas, nama_kelas, harga, total_kursi, sisa_kursi
        FROM kelas_kereta
        WHERE id_kereta = ?
        ORDER BY harga
    """, (id_kereta,)).fetchall()
    conn.close()
    return rows


def kurangi_sisa_kursi(id_kelas: int, jumlah: int):
    conn = get_connection()
    conn.execute(
        "UPDATE kelas_kereta SET sisa_kursi = sisa_kursi - ? WHERE id_kelas = ?",
        (jumlah, id_kelas)
    )
    conn.commit()
    conn.close()


def tambah_sisa_kursi(id_kelas: int, jumlah: int):
    conn = get_connection()
    conn.execute(
        "UPDATE kelas_kereta SET sisa_kursi = sisa_kursi + ? WHERE id_kelas = ?",
        (jumlah, id_kelas)
    )
    conn.commit()
    conn.close()


def simpan_penumpang(nama, nik, email, telepon):
    conn = get_connection()
    # Upsert: jika NIK sudah ada, kembalikan id-nya
    cur = conn.cursor()
    cur.execute("SELECT id_penumpang FROM penumpang WHERE nik = ?", (nik,))
    row = cur.fetchone()
    if row:
        conn.close()
        return row[0]
    cur.execute(
        "INSERT INTO penumpang (nama,nik,email,telepon) VALUES (?,?,?,?)",
        (nama, nik, email, telepon)
    )
    conn.commit()
    id_baru = cur.lastrowid
    conn.close()
    return id_baru


def simpan_pemesanan(kode_booking, id_penumpang, id_kelas,
                     jumlah_tiket, total_harga, tanggal_berangkat):
    from datetime import date
    conn = get_connection()
    conn.execute(
        """INSERT INTO pemesanan
           (kode_booking,id_penumpang,id_kelas,jumlah_tiket,
            total_harga,status,tanggal_pesan,tanggal_berangkat)
           VALUES (?,?,?,?,?,'PENDING',?,?)""",
        (kode_booking, id_penumpang, id_kelas, jumlah_tiket,
         total_harga, str(date.today()), tanggal_berangkat)
    )
    conn.commit()
    conn.close()


def update_status_pemesanan(kode_booking: str, status: str):
    conn = get_connection()
    conn.execute(
        "UPDATE pemesanan SET status = ? WHERE kode_booking = ?",
        (status, kode_booking)
    )
    conn.commit()
    conn.close()


def ambil_pemesanan_by_kode(kode_booking: str):
    conn = get_connection()
    row = conn.execute("""
        SELECT p.kode_booking, p.jumlah_tiket, p.total_harga,
               p.status, p.tanggal_pesan, p.tanggal_berangkat,
               pn.nama, pn.nik, pn.email, pn.telepon,
               k.nama_kereta, k.asal, k.tujuan,
               k.jam_berangkat, k.jam_tiba,
               kl.nama_kelas, kl.harga
        FROM pemesanan p
        JOIN penumpang  pn ON pn.id_penumpang = p.id_penumpang
        JOIN kelas_kereta kl ON kl.id_kelas   = p.id_kelas
        JOIN kereta       k  ON k.id_kereta   = kl.id_kereta
        WHERE p.kode_booking = ?
    """, (kode_booking,)).fetchone()
    conn.close()
    return row


def ambil_semua_pemesanan():
    conn = get_connection()
    rows = conn.execute("""
        SELECT p.kode_booking, pn.nama, k.nama_kereta,
               kl.nama_kelas, p.jumlah_tiket, p.total_harga,
               p.status, p.tanggal_berangkat
        FROM pemesanan p
        JOIN penumpang    pn ON pn.id_penumpang = p.id_penumpang
        JOIN kelas_kereta kl ON kl.id_kelas     = p.id_kelas
        JOIN kereta       k  ON k.id_kereta     = kl.id_kereta
        ORDER BY p.id_pemesanan DESC
    """).fetchall()
    conn.close()
    return rows
