# 🚂 Sistem Pemesanan Tiket Kereta Api

**Final Project — Object-Oriented Programming (OOP)**
> Aplikasi CLI berbasis Python untuk simulasi pemesanan tiket kereta api dengan database SQLite.

---

## 📋 Deskripsi Proyek

Aplikasi ini mensimulasikan sistem pemesanan tiket kereta api secara interaktif melalui terminal. Pengguna dapat melihat daftar kereta, memesan tiket, melakukan pembayaran, mengecek status, hingga membatalkan tiket. Seluruh data tersimpan di database SQLite lokal.

---

## 🗂️ Struktur File

```
Final_Project/
│
├── main.py          # Entry point & menu interaktif CLI
├── models.py        # Kelas OOP (Kereta, Penumpang, Tiket & subclass)
├── database.py      # Layer database SQLite (CRUD operations)
├── exceptions.py    # Custom exception classes
├── schema.sql       # DDL + DML + Query SQL lengkap (referensi)
├── kereta.db        # File database SQLite (dibuat otomatis saat pertama run)
├── requirements.txt # Dependensi proyek
└── README.md        # Dokumentasi proyek
```

---

## ✅ Implementasi Pilar OOP

| Pilar / Fitur | Implementasi |
|---|---|
| **Encapsulation** | Atribut private (`__nama`, `__harga_satuan`, dll.) dengan getter `@property` dan setter bervalidasi di kelas `Kereta`, `Penumpang`, `Tiket` |
| **Inheritance** | `TiketEkonomi`, `TiketBisnis`, `TiketEksekutif` mewarisi kelas dasar `Tiket` |
| **Polymorphism** | Method `info_kelas()` di-override berbeda di tiap subclass; factory function `buat_tiket()` memilih subclass secara dinamis |
| **Magic Methods** | `__init__`, `__str__`, `__repr__`, `__eq__`, `__lt__` diimplementasikan di semua kelas |
| **Static Methods** | `Tiket.generate_kode_booking()` dan `Tiket.validasi_tanggal()` |
| **Instance Methods** | `hitung_total()`, `bayar()`, `batalkan()` pada kelas `Tiket` |
| **Custom Exception** | `KeretaException` (base), `TiketTidakTersediaException`, `PembayaranGagalException`, `InputTidakValidException`, `KodeBookingTidakDitemukanException`, `PenumpangTidakDitemukanException` |
| **Exception Handling** | Try-except menangkap custom & built-in exception di setiap fitur menu |

---

## 🚀 Cara Menjalankan Aplikasi

### Prasyarat
- Python **3.8** atau lebih baru (cek: `python --version`)
- Tidak ada library eksternal yang perlu diinstal (semua menggunakan stdlib Python)

### Langkah Menjalankan

```bash
# 1. Clone repository (jika dari GitHub)
git clone https://github.com/username/OOP_Nama_NIM.git
cd OOP_Nama_NIM/Final_Project

# 2. Jalankan aplikasi
python main.py
```

> **Catatan:** File `kereta.db` akan dibuat otomatis di folder yang sama saat pertama kali dijalankan.

---

## 🖥️ Fitur Aplikasi

```
MENU UTAMA:

[1]  Lihat Daftar Kereta      → Menampilkan semua kereta & rute
[2]  Pesan Tiket              → Proses pemesanan + pembayaran
[3]  Cek Status Tiket         → Cek tiket via kode booking
[4]  Batalkan Tiket           → Pembatalan & pengembalian kursi
[5]  Riwayat Pemesanan        → Seluruh histori transaksi
[0]  Keluar
```

### Alur Pemesanan Tiket
1. Pilih kereta dari daftar
2. Pilih kelas (Ekonomi / Bisnis / Eksekutif)
3. Tentukan jumlah tiket & tanggal berangkat
4. Isi data penumpang (Nama, NIK 16 digit, Email, Telepon)
5. Pilih apakah pelajar (diskon 10%)
6. Konfirmasi & bayar
7. Terima kode booking

---

## 🗄️ Skema Database (SQLite)

```sql
kereta        : id_kereta, nama_kereta, kode_kereta, asal, tujuan, jam_berangkat, jam_tiba
kelas_kereta  : id_kelas, id_kereta*, nama_kelas, harga, total_kursi, sisa_kursi
penumpang     : id_penumpang, nama, nik (UNIQUE), email, telepon
pemesanan     : id_pemesanan, kode_booking (UNIQUE), id_penumpang*, id_kelas*,
                jumlah_tiket, total_harga, status, tanggal_pesan, tanggal_berangkat
```

Lihat file `schema.sql` untuk DDL lengkap, contoh INSERT/UPDATE/SELECT, dan query laporan.

---

## 📊 Contoh Output

```
============================================================
       🚂  SISTEM PEMESANAN TIKET KERETA API  🚂
       PT Kereta Api Indonesia (KAI) — Simulasi
============================================================

  [1] [ABA] Argo Bromo Anggrek | Jakarta Gambir → Surabaya Pasar Turi | Berangkat: 08:00  Tiba: 17:30
  [2] [BIM] Bima               | Jakarta Gambir → Surabaya Gubeng      | Berangkat: 17:00  Tiba: 05:30
  ...
```

---

## 🔧 Penjelasan Teknis

### Custom Exception Hierarchy
```
Exception
└── KeretaException
    ├── TiketTidakTersediaException
    ├── PembayaranGagalException
    ├── PenumpangTidakDitemukanException
    ├── InputTidakValidException
    └── KodeBookingTidakDitemukanException
```

### Class Hierarchy (Inheritance)
```
object
├── Kereta
├── Penumpang
└── Tiket                  ← Base class
    ├── TiketEkonomi        ← override info_kelas()
    ├── TiketBisnis         ← override info_kelas()
    └── TiketEksekutif      ← override info_kelas()
```

---

## 📝 Catatan Pengembangan

- Database SQLite dipilih agar aplikasi bisa berjalan *standalone* tanpa server
- Kode booking di-generate secara acak menggunakan `random.choices()` (Static Method)
- Diskon pelajar 10% diimplementasikan sebagai *class variable* (`Tiket.DISKON_PELAJAR`)
- Validasi input dilakukan di level model (raise exception) dan di level UI (looping input)

---

## 👤 Identitas Mahasiswa

| | |
|---|---|
| **Nama** | [Nama Mahasiswa] |
| **NIM** | [NIM] |
| **Kelas** | [Kelas] |
| **Mata Kuliah** | Pemrograman Berorientasi Objek |
| **Semester** | [Semester] |

---

## 📄 Lisensi

Proyek ini dibuat untuk keperluan akademik Final Project OOP.
