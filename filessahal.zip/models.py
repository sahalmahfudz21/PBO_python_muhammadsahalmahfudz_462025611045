# ============================================================
#   models.py — OOP Models
#   Sistem Pemesanan Tiket Kereta Api
#
#   Pilar OOP yang diimplementasikan:
#   ✅ Encapsulation  — atribut private dengan getter/setter
#   ✅ Inheritance    — Tiket → TiketEkonomi / TiketBisnis / TiketEksekutif
#   ✅ Polymorphism   — method info_kelas() di-override tiap subclass
#   ✅ Magic Methods  — __init__, __str__, __repr__, __eq__, __lt__
#   ✅ Static Methods — Tiket.generate_kode_booking()
#   ✅ Instance Methods — beli(), batalkan(), hitung_total()
# ============================================================

import random
import string
from datetime import datetime
from exceptions import (
    TiketTidakTersediaException,
    PembayaranGagalException,
    InputTidakValidException,
)


# ──────────────────────────────────────────────
# 1. KELAS KERETA  (enkapsulasi data kereta)
# ──────────────────────────────────────────────
class Kereta:
    """Merepresentasikan satu rangkaian kereta beserta rutenya."""

    def __init__(self, id_kereta, nama_kereta, kode_kereta,
                 asal, tujuan, jam_berangkat, jam_tiba):
        self.__id_kereta    = id_kereta
        self.__nama_kereta  = nama_kereta
        self.__kode_kereta  = kode_kereta
        self.__asal         = asal
        self.__tujuan       = tujuan
        self.__jam_berangkat = jam_berangkat
        self.__jam_tiba     = jam_tiba

    # --- Getters (enkapsulasi) ---
    @property
    def id_kereta(self):     return self.__id_kereta
    @property
    def nama_kereta(self):   return self.__nama_kereta
    @property
    def kode_kereta(self):   return self.__kode_kereta
    @property
    def asal(self):          return self.__asal
    @property
    def tujuan(self):        return self.__tujuan
    @property
    def jam_berangkat(self): return self.__jam_berangkat
    @property
    def jam_tiba(self):      return self.__jam_tiba

    # --- Magic Methods ---
    def __str__(self):
        return (f"[{self.__kode_kereta}] {self.__nama_kereta} | "
                f"{self.__asal} → {self.__tujuan} | "
                f"Berangkat: {self.__jam_berangkat}  Tiba: {self.__jam_tiba}")

    def __repr__(self):
        return f"Kereta(id={self.__id_kereta}, kode='{self.__kode_kereta}')"

    def __eq__(self, other):
        return isinstance(other, Kereta) and self.__id_kereta == other.__id_kereta


# ──────────────────────────────────────────────
# 2. PENUMPANG  (enkapsulasi data pribadi)
# ──────────────────────────────────────────────
class Penumpang:
    """Merepresentasikan penumpang / pemesan tiket."""

    def __init__(self, nama: str, nik: str, email: str = "", telepon: str = ""):
        if not nama.strip():
            raise InputTidakValidException("nama", nama)
        if len(nik) != 16 or not nik.isdigit():
            raise InputTidakValidException("NIK (harus 16 digit angka)", nik)

        self.__nama    = nama.strip().title()
        self.__nik     = nik
        self.__email   = email.strip()
        self.__telepon = telepon.strip()
        self._id       = None   # diisi setelah disimpan ke DB

    # --- Getters ---
    @property
    def nama(self):    return self.__nama
    @property
    def nik(self):     return self.__nik
    @property
    def email(self):   return self.__email
    @property
    def telepon(self): return self.__telepon

    # --- Setter dengan validasi ---
    @email.setter
    def email(self, val: str):
        if "@" not in val:
            raise InputTidakValidException("email", val)
        self.__email = val.strip()

    # --- Magic Methods ---
    def __str__(self):
        return f"Penumpang: {self.__nama} (NIK: {self.__nik})"

    def __repr__(self):
        return f"Penumpang(nama='{self.__nama}', nik='{self.__nik}')"


# ──────────────────────────────────────────────
# 3. TIKET (Base Class) — Inheritance & Encapsulation
# ──────────────────────────────────────────────
class Tiket:
    """
    Kelas dasar untuk semua jenis tiket kereta.
    Subclass harus mengimplementasikan method info_kelas().
    """

    DISKON_PELAJAR = 0.10   # class variable: 10 %

    def __init__(self, kereta: Kereta, penumpang: Penumpang,
                 id_kelas: int, nama_kelas: str,
                 harga_satuan: float, sisa_kursi: int,
                 jumlah_tiket: int, tanggal_berangkat: str):

        if jumlah_tiket < 1:
            raise InputTidakValidException("jumlah_tiket", jumlah_tiket)
        if sisa_kursi < jumlah_tiket:
            raise TiketTidakTersediaException(nama_kelas, jumlah_tiket)

        self._kereta          = kereta
        self._penumpang       = penumpang
        self._id_kelas        = id_kelas
        self._nama_kelas      = nama_kelas
        self.__harga_satuan   = harga_satuan   # private
        self._sisa_kursi      = sisa_kursi
        self._jumlah_tiket    = jumlah_tiket
        self._tanggal_berangkat = tanggal_berangkat
        self._kode_booking    = Tiket.generate_kode_booking()
        self._status          = "PENDING"

    # ---- Static Method ----
    @staticmethod
    def generate_kode_booking() -> str:
        """Generate kode booking unik 8 karakter (huruf besar + angka)."""
        chars = string.ascii_uppercase + string.digits
        return "KA-" + "".join(random.choices(chars, k=8))

    # ---- Static Method ----
    @staticmethod
    def validasi_tanggal(tanggal_str: str) -> bool:
        """Memvalidasi format tanggal YYYY-MM-DD."""
        try:
            datetime.strptime(tanggal_str, "%Y-%m-%d")
            return True
        except ValueError:
            return False

    # ---- Instance Methods ----
    def hitung_total(self, is_pelajar: bool = False) -> float:
        """Menghitung total harga dengan/tanpa diskon pelajar."""
        total = self.__harga_satuan * self._jumlah_tiket
        if is_pelajar:
            total *= (1 - Tiket.DISKON_PELAJAR)
        return total

    def bayar(self, jumlah_bayar: float, is_pelajar: bool = False):
        """Memproses pembayaran tiket."""
        total = self.hitung_total(is_pelajar)
        if jumlah_bayar < total:
            raise PembayaranGagalException(jumlah_bayar, total)
        self._status = "LUNAS"
        kembalian = jumlah_bayar - total
        return total, kembalian

    def batalkan(self):
        """Membatalkan pemesanan."""
        if self._status == "BATAL":
            raise Exception("Tiket sudah dibatalkan sebelumnya.")
        self._status = "BATAL"

    # ---- Polymorphism: harus di-override subclass ----
    def info_kelas(self) -> str:
        raise NotImplementedError("Subclass harus mengimplementasikan info_kelas().")

    # ---- Getters ----
    @property
    def kode_booking(self):       return self._kode_booking
    @property
    def status(self):             return self._status
    @property
    def harga_satuan(self):       return self.__harga_satuan
    @property
    def jumlah_tiket(self):       return self._jumlah_tiket
    @property
    def nama_kelas(self):         return self._nama_kelas
    @property
    def tanggal_berangkat(self):  return self._tanggal_berangkat

    # ---- Magic Methods ----
    def __str__(self):
        return (
            f"\n{'='*55}\n"
            f"  TIKET KERETA API — {self._nama_kelas.upper()}\n"
            f"{'='*55}\n"
            f"  Kode Booking   : {self._kode_booking}\n"
            f"  Kereta         : {self._kereta.nama_kereta}\n"
            f"  Rute           : {self._kereta.asal} → {self._kereta.tujuan}\n"
            f"  Berangkat      : {self._kereta.jam_berangkat}  |  "
            f"Tiba: {self._kereta.jam_tiba}\n"
            f"  Tgl Berangkat  : {self._tanggal_berangkat}\n"
            f"  Penumpang      : {self._penumpang.nama}\n"
            f"  NIK            : {self._penumpang.nik}\n"
            f"  Kelas          : {self._nama_kelas}  ({self.info_kelas()})\n"
            f"  Jumlah Tiket   : {self._jumlah_tiket}\n"
            f"  Harga/Tiket    : Rp{self.__harga_satuan:>12,.0f}\n"
            f"  Total          : Rp{self.hitung_total():>12,.0f}\n"
            f"  Status         : {self._status}\n"
            f"{'='*55}"
        )

    def __repr__(self):
        return f"Tiket(kode='{self._kode_booking}', status='{self._status}')"

    def __eq__(self, other):
        return isinstance(other, Tiket) and self._kode_booking == other._kode_booking

    def __lt__(self, other):
        """Bandingkan berdasarkan harga satuan (untuk sorting)."""
        return self.harga_satuan < other.harga_satuan


# ──────────────────────────────────────────────
# 4. SUBCLASS TIKET — Polymorphism via info_kelas()
# ──────────────────────────────────────────────
class TiketEkonomi(Tiket):
    """Tiket kelas Ekonomi — fasilitas standar."""

    def info_kelas(self) -> str:
        return "Kursi tegak, AC, toilet tersedia"

    def __str__(self):
        base = super().__str__()
        return base + "\n  [Info] Kelas Ekonomi: Kursi 2-3, non-reclining.\n"


class TiketBisnis(Tiket):
    """Tiket kelas Bisnis — fasilitas menengah."""

    def info_kelas(self) -> str:
        return "Kursi reclining, AC, colokan listrik"

    def __str__(self):
        base = super().__str__()
        return base + "\n  [Info] Kelas Bisnis: Kursi 2-2, semi-reclining.\n"


class TiketEksekutif(Tiket):
    """Tiket kelas Eksekutif — fasilitas premium."""

    def info_kelas(self) -> str:
        return "Kursi fully reclining, selimut, snack, colokan listrik"

    def __str__(self):
        base = super().__str__()
        return base + "\n  [Info] Kelas Eksekutif: Kursi 2-2, fully-reclining, premium.\n"


# ──────────────────────────────────────────────
# 5. FACTORY FUNCTION
# ──────────────────────────────────────────────
def buat_tiket(kereta, penumpang, id_kelas, nama_kelas,
               harga, sisa_kursi, jumlah, tanggal) -> Tiket:
    """
    Factory function: memilih subclass Tiket yang tepat
    berdasarkan nama_kelas (Polymorphism via duck-typing).
    """
    mapping = {
        "Ekonomi":   TiketEkonomi,
        "Bisnis":    TiketBisnis,
        "Eksekutif": TiketEksekutif,
    }
    cls = mapping.get(nama_kelas)
    if cls is None:
        raise InputTidakValidException("nama_kelas", nama_kelas)
    return cls(kereta, penumpang, id_kelas, nama_kelas,
               harga, sisa_kursi, jumlah, tanggal)
