-- ============================================================
--  schema.sql — DDL & DML Lengkap
--  Sistem Pemesanan Tiket Kereta Api
--  Database: SQLite (kereta.db)
-- ============================================================

PRAGMA foreign_keys = ON;

-- ============================================================
-- DDL — DATA DEFINITION LANGUAGE
-- ============================================================

-- Tabel kereta: menyimpan data rangkaian kereta
CREATE TABLE IF NOT EXISTS kereta (
    id_kereta     INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_kereta   TEXT    NOT NULL,
    kode_kereta   TEXT    NOT NULL UNIQUE,
    asal          TEXT    NOT NULL,
    tujuan        TEXT    NOT NULL,
    jam_berangkat TEXT    NOT NULL,
    jam_tiba      TEXT    NOT NULL
);

-- Tabel kelas_kereta: kelas & harga tiap kereta
CREATE TABLE IF NOT EXISTS kelas_kereta (
    id_kelas    INTEGER PRIMARY KEY AUTOINCREMENT,
    id_kereta   INTEGER NOT NULL,
    nama_kelas  TEXT    NOT NULL,   -- Ekonomi | Bisnis | Eksekutif
    harga       REAL    NOT NULL,
    total_kursi INTEGER NOT NULL,
    sisa_kursi  INTEGER NOT NULL,
    FOREIGN KEY (id_kereta) REFERENCES kereta(id_kereta)
);

-- Tabel penumpang: data diri pemesan
CREATE TABLE IF NOT EXISTS penumpang (
    id_penumpang INTEGER PRIMARY KEY AUTOINCREMENT,
    nama         TEXT NOT NULL,
    nik          TEXT NOT NULL UNIQUE,
    email        TEXT,
    telepon      TEXT
);

-- Tabel pemesanan: transaksi pemesanan tiket
CREATE TABLE IF NOT EXISTS pemesanan (
    id_pemesanan      INTEGER PRIMARY KEY AUTOINCREMENT,
    kode_booking      TEXT    NOT NULL UNIQUE,
    id_penumpang      INTEGER NOT NULL,
    id_kelas          INTEGER NOT NULL,
    jumlah_tiket      INTEGER NOT NULL DEFAULT 1,
    total_harga       REAL    NOT NULL,
    status            TEXT    NOT NULL DEFAULT 'PENDING',   -- PENDING | LUNAS | BATAL
    tanggal_pesan     TEXT    NOT NULL,   -- format YYYY-MM-DD
    tanggal_berangkat TEXT    NOT NULL,
    FOREIGN KEY (id_penumpang) REFERENCES penumpang(id_penumpang),
    FOREIGN KEY (id_kelas)     REFERENCES kelas_kereta(id_kelas)
);


-- ============================================================
-- DML — DATA MANIPULATION LANGUAGE (Seed / Contoh Query)
-- ============================================================

-- INSERT data kereta awal
INSERT INTO kereta (nama_kereta, kode_kereta, asal, tujuan, jam_berangkat, jam_tiba)
VALUES
    ('Argo Bromo Anggrek', 'ABA', 'Jakarta Gambir', 'Surabaya Pasar Turi', '08:00', '17:30'),
    ('Bima',               'BIM', 'Jakarta Gambir', 'Surabaya Gubeng',      '17:00', '05:30'),
    ('Gajayana',           'GAJ', 'Jakarta Gambir', 'Malang',               '17:45', '07:00'),
    ('Lodaya',             'LOD', 'Bandung',        'Solo Balapan',         '08:10', '16:15'),
    ('Taksaka',            'TAK', 'Jakarta Gambir', 'Yogyakarta',           '10:00', '17:00');

-- INSERT kelas untuk Argo Bromo Anggrek (id_kereta = 1)
INSERT INTO kelas_kereta (id_kereta, nama_kelas, harga, total_kursi, sisa_kursi)
VALUES
    (1, 'Ekonomi',   250000, 80, 80),
    (1, 'Bisnis',    400000, 50, 50),
    (1, 'Eksekutif', 650000, 30, 30);

-- INSERT contoh penumpang
INSERT INTO penumpang (nama, nik, email, telepon)
VALUES ('Budi Santoso', '3578010101900001', 'budi@email.com', '081234567890');

-- INSERT contoh pemesanan
INSERT INTO pemesanan
    (kode_booking, id_penumpang, id_kelas, jumlah_tiket, total_harga, status, tanggal_pesan, tanggal_berangkat)
VALUES
    ('KA-CONTOH01', 1, 1, 2, 500000, 'LUNAS', '2025-08-01', '2025-08-20');

-- UPDATE status pemesanan
UPDATE pemesanan SET status = 'LUNAS' WHERE kode_booking = 'KA-CONTOH01';

-- UPDATE sisa kursi setelah pemesanan
UPDATE kelas_kereta SET sisa_kursi = sisa_kursi - 2 WHERE id_kelas = 1;


-- ============================================================
-- SELECT — QUERY LAPORAN
-- ============================================================

-- 1. Semua kereta dengan rute
SELECT id_kereta, nama_kereta, kode_kereta, asal, tujuan, jam_berangkat, jam_tiba
FROM kereta
ORDER BY id_kereta;

-- 2. Kelas & harga satu kereta
SELECT kl.nama_kelas, kl.harga, kl.sisa_kursi
FROM kelas_kereta kl
WHERE kl.id_kereta = 1
ORDER BY kl.harga;

-- 3. Detail pemesanan lengkap (JOIN 4 tabel)
SELECT
    p.kode_booking,
    pn.nama          AS nama_penumpang,
    pn.nik,
    k.nama_kereta,
    k.asal,
    k.tujuan,
    kl.nama_kelas,
    p.jumlah_tiket,
    p.total_harga,
    p.status,
    p.tanggal_pesan,
    p.tanggal_berangkat
FROM pemesanan p
JOIN penumpang    pn ON pn.id_penumpang = p.id_penumpang
JOIN kelas_kereta kl ON kl.id_kelas    = p.id_kelas
JOIN kereta       k  ON k.id_kereta    = kl.id_kereta
ORDER BY p.id_pemesanan DESC;

-- 4. Rekap pendapatan per kereta
SELECT
    k.nama_kereta,
    COUNT(p.id_pemesanan)  AS total_transaksi,
    SUM(p.jumlah_tiket)    AS total_tiket_terjual,
    SUM(p.total_harga)     AS total_pendapatan
FROM pemesanan p
JOIN kelas_kereta kl ON kl.id_kelas  = p.id_kelas
JOIN kereta       k  ON k.id_kereta  = kl.id_kereta
WHERE p.status = 'LUNAS'
GROUP BY k.id_kereta, k.nama_kereta
ORDER BY total_pendapatan DESC;

-- 5. Pemesanan dengan status tertentu
SELECT kode_booking, status, tanggal_berangkat
FROM pemesanan
WHERE status = 'PENDING';

-- 6. Kereta dengan sisa kursi paling sedikit
SELECT k.nama_kereta, kl.nama_kelas, kl.sisa_kursi
FROM kelas_kereta kl
JOIN kereta k ON k.id_kereta = kl.id_kereta
ORDER BY kl.sisa_kursi ASC
LIMIT 5;

-- DELETE contoh (pembatalan)
-- UPDATE pemesanan SET status = 'BATAL' WHERE kode_booking = 'KA-CONTOH01';
-- UPDATE kelas_kereta SET sisa_kursi = sisa_kursi + 2 WHERE id_kelas = 1;
