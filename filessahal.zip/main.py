#!/usr/bin/env python3
# ============================================================
#   main.py — Entry Point & Interactive CLI
#   Sistem Pemesanan Tiket Kereta Api
#   Dikerjakan sebagai Final Project OOP
# ============================================================

import os
import sys
from datetime import date

import database as db
from models import Kereta, Penumpang, buat_tiket
from exceptions import (
    KeretaException,
    TiketTidakTersediaException,
    PembayaranGagalException,
    InputTidakValidException,
    KodeBookingTidakDitemukanException,
)


# ──────────────────────────────────────────────
# UTILITAS TAMPILAN
# ──────────────────────────────────────────────
def bersihkan_layar():
    os.system("cls" if os.name == "nt" else "clear")


def cetak_header():
    print("=" * 60)
    print("       🚂  SISTEM PEMESANAN TIKET KERETA API  🚂")
    print("       PT Kereta Api Indonesia (KAI) — Simulasi")
    print("=" * 60)


def cetak_garis():
    print("-" * 60)


def input_int(prompt: str, min_val=None, max_val=None) -> int:
    """Input integer dengan validasi range."""
    while True:
        try:
            val = int(input(prompt))
            if min_val is not None and val < min_val:
                print(f"  ⚠  Nilai minimal: {min_val}")
                continue
            if max_val is not None and val > max_val:
                print(f"  ⚠  Nilai maksimal: {max_val}")
                continue
            return val
        except ValueError:
            print("  ⚠  Masukkan angka yang valid.")


def input_float(prompt: str) -> float:
    while True:
        try:
            val = float(input(prompt).replace(",", "").replace(".", ""))
            if val < 0:
                print("  ⚠  Nilai tidak boleh negatif.")
                continue
            return val
        except ValueError:
            print("  ⚠  Masukkan nominal yang valid (contoh: 500000).")


# ──────────────────────────────────────────────
# FITUR 1 — Tampilkan Daftar Kereta
# ──────────────────────────────────────────────
def tampilkan_daftar_kereta():
    bersihkan_layar()
    cetak_header()
    print("\n  📋  DAFTAR KERETA TERSEDIA\n")
    cetak_garis()

    rows = db.ambil_semua_kereta()
    if not rows:
        print("  Belum ada data kereta.")
        return []

    kereta_list = []
    for i, r in enumerate(rows, 1):
        k = Kereta(r["id_kereta"], r["nama_kereta"], r["kode_kereta"],
                   r["asal"], r["tujuan"], r["jam_berangkat"], r["jam_tiba"])
        print(f"  [{i}] {k}")
        kereta_list.append(k)

    cetak_garis()
    return kereta_list


# ──────────────────────────────────────────────
# FITUR 2 — Pesan Tiket
# ──────────────────────────────────────────────
def pesan_tiket():
    kereta_list = tampilkan_daftar_kereta()
    if not kereta_list:
        input("\n  Tekan Enter untuk kembali...")
        return

    try:
        # --- Pilih kereta ---
        pilih = input_int("\n  Pilih nomor kereta: ", 1, len(kereta_list))
        kereta = kereta_list[pilih - 1]

        # --- Pilih kelas ---
        kelas_rows = db.ambil_kelas_by_kereta(kereta.id_kereta)
        print(f"\n  Kelas yang tersedia untuk {kereta.nama_kereta}:\n")
        cetak_garis()
        for i, kr in enumerate(kelas_rows, 1):
            print(f"  [{i}] {kr['nama_kelas']:<12} "
                  f"Rp{kr['harga']:>10,.0f}  |  "
                  f"Sisa kursi: {kr['sisa_kursi']}")
        cetak_garis()

        pilih_kelas = input_int("\n  Pilih nomor kelas: ", 1, len(kelas_rows))
        kelas = kelas_rows[pilih_kelas - 1]

        # --- Jumlah tiket ---
        jumlah = input_int("  Jumlah tiket (maks 4): ", 1, 4)

        # --- Tanggal berangkat ---
        print(f"  Tanggal berangkat (format YYYY-MM-DD, min: {date.today()}):")
        while True:
            tgl_str = input("  > ").strip()
            from models import Tiket
            if not Tiket.validasi_tanggal(tgl_str):
                print("  ⚠  Format tanggal salah. Contoh: 2025-08-20")
                continue
            from datetime import datetime
            if datetime.strptime(tgl_str, "%Y-%m-%d").date() < date.today():
                print("  ⚠  Tanggal tidak boleh sebelum hari ini.")
                continue
            break

        # --- Data penumpang ---
        print("\n  📋  DATA PENUMPANG")
        cetak_garis()
        nama    = input("  Nama Lengkap : ").strip()
        nik     = input("  NIK (16 digit): ").strip()
        email   = input("  Email        : ").strip()
        telepon = input("  Telepon      : ").strip()

        penumpang = Penumpang(nama, nik, email, telepon)

        # --- Buat objek tiket (Factory + Polymorphism) ---
        tiket = buat_tiket(
            kereta, penumpang,
            kelas["id_kelas"], kelas["nama_kelas"],
            kelas["harga"], kelas["sisa_kursi"],
            jumlah, tgl_str
        )

        # --- Diskon pelajar ---
        is_pelajar = input("\n  Apakah Anda pelajar/mahasiswa? (y/n): ").lower() == "y"
        total = tiket.hitung_total(is_pelajar)
        if is_pelajar:
            print(f"  🎓 Diskon pelajar 10% diterapkan!")

        # --- Ringkasan & konfirmasi ---
        print(tiket)
        if is_pelajar:
            print(f"  Total setelah diskon: Rp{total:,.0f}")

        konfirmasi = input("\n  Lanjutkan pembayaran? (y/n): ").lower()
        if konfirmasi != "y":
            print("  ❌ Pemesanan dibatalkan.")
            input("\n  Tekan Enter untuk kembali...")
            return

        # --- Pembayaran ---
        print(f"\n  Total yang harus dibayar: Rp{total:,.0f}")
        bayar = input_float("  Masukkan jumlah pembayaran (Rp): ")
        total_final, kembalian = tiket.bayar(bayar, is_pelajar)

        # --- Simpan ke database ---
        id_penumpang = db.simpan_penumpang(
            penumpang.nama, penumpang.nik,
            penumpang.email, penumpang.telepon
        )
        db.simpan_pemesanan(
            tiket.kode_booking, id_penumpang,
            kelas["id_kelas"], jumlah,
            total_final, tgl_str
        )
        db.update_status_pemesanan(tiket.kode_booking, "LUNAS")
        db.kurangi_sisa_kursi(kelas["id_kelas"], jumlah)

        # --- Struk ---
        print("\n  ✅  PEMBAYARAN BERHASIL!")
        print(f"  Kode Booking  : {tiket.kode_booking}")
        print(f"  Dibayar       : Rp{bayar:,.0f}")
        print(f"  Total         : Rp{total_final:,.0f}")
        print(f"  Kembalian     : Rp{kembalian:,.0f}")
        print("\n  Simpan kode booking Anda untuk pengecekan tiket.")

    except TiketTidakTersediaException as e:
        print(f"\n  ❌ {e}")
    except PembayaranGagalException as e:
        print(f"\n  ❌ {e}")
    except InputTidakValidException as e:
        print(f"\n  ❌ {e}")
    except KeretaException as e:
        print(f"\n  ❌ {e}")
    except Exception as e:
        print(f"\n  ❌ Kesalahan tidak terduga: {e}")

    input("\n  Tekan Enter untuk kembali ke menu...")


# ──────────────────────────────────────────────
# FITUR 3 — Cek Status Tiket
# ──────────────────────────────────────────────
def cek_tiket():
    bersihkan_layar()
    cetak_header()
    print("\n  🔍  CEK STATUS TIKET\n")

    kode = input("  Masukkan kode booking (cth: KA-XXXXXXXX): ").strip().upper()

    try:
        row = db.ambil_pemesanan_by_kode(kode)
        if not row:
            raise KodeBookingTidakDitemukanException(kode)

        print("\n" + "=" * 55)
        print("  DETAIL TIKET")
        print("=" * 55)
        print(f"  Kode Booking     : {row['kode_booking']}")
        print(f"  Status           : {row['status']}")
        print(f"  Penumpang        : {row['nama']}")
        print(f"  NIK              : {row['nik']}")
        print(f"  Kereta           : {row['nama_kereta']}")
        print(f"  Rute             : {row['asal']} → {row['tujuan']}")
        print(f"  Tgl Berangkat    : {row['tanggal_berangkat']}")
        print(f"  Kelas            : {row['nama_kelas']}")
        print(f"  Jumlah Tiket     : {row['jumlah_tiket']}")
        print(f"  Total Harga      : Rp{row['total_harga']:,.0f}")
        print("=" * 55)

    except KodeBookingTidakDitemukanException as e:
        print(f"\n  ❌ {e}")

    input("\n  Tekan Enter untuk kembali ke menu...")


# ──────────────────────────────────────────────
# FITUR 4 — Batalkan Tiket
# ──────────────────────────────────────────────
def batalkan_tiket():
    bersihkan_layar()
    cetak_header()
    print("\n  ❌  PEMBATALAN TIKET\n")

    kode = input("  Masukkan kode booking: ").strip().upper()

    try:
        row = db.ambil_pemesanan_by_kode(kode)
        if not row:
            raise KodeBookingTidakDitemukanException(kode)

        if row["status"] == "BATAL":
            print("  ⚠  Tiket ini sudah dibatalkan sebelumnya.")
            input("\n  Tekan Enter untuk kembali...")
            return

        print(f"\n  Tiket ditemukan: {row['nama_kereta']} | {row['nama_kelas']}")
        print(f"  Penumpang      : {row['nama']}")
        print(f"  Total Harga    : Rp{row['total_harga']:,.0f}")
        konfirmasi = input("\n  Yakin ingin membatalkan tiket ini? (y/n): ").lower()

        if konfirmasi == "y":
            db.update_status_pemesanan(kode, "BATAL")
            # Kembalikan kursi
            kelas_rows = db.ambil_kelas_by_kereta(
                db.get_connection().execute(
                    "SELECT id_kereta FROM kelas_kereta WHERE id_kelas = "
                    "(SELECT id_kelas FROM pemesanan WHERE kode_booking=?)", (kode,)
                ).fetchone()[0]
            )
            # Dapatkan id_kelas dari pemesanan
            conn = db.get_connection()
            id_kelas = conn.execute(
                "SELECT id_kelas, jumlah_tiket FROM pemesanan WHERE kode_booking=?",
                (kode,)
            ).fetchone()
            conn.close()
            db.tambah_sisa_kursi(id_kelas[0], id_kelas[1])
            print("  ✅  Tiket berhasil dibatalkan. Kursi telah dikembalikan.")
        else:
            print("  Pembatalan dibatalkan.")

    except KodeBookingTidakDitemukanException as e:
        print(f"\n  ❌ {e}")

    input("\n  Tekan Enter untuk kembali ke menu...")


# ──────────────────────────────────────────────
# FITUR 5 — Riwayat Pemesanan
# ──────────────────────────────────────────────
def riwayat_pemesanan():
    bersihkan_layar()
    cetak_header()
    print("\n  📜  RIWAYAT SEMUA PEMESANAN\n")
    cetak_garis()

    rows = db.ambil_semua_pemesanan()
    if not rows:
        print("  Belum ada data pemesanan.")
    else:
        print(f"  {'Kode Booking':<14} {'Penumpang':<20} {'Kereta':<22} "
              f"{'Kelas':<11} {'Tiket':>5} {'Total':>12} {'Status':<8}")
        cetak_garis()
        for r in rows:
            print(f"  {r['kode_booking']:<14} {r['nama']:<20} "
                  f"{r['nama_kereta']:<22} {r['nama_kelas']:<11} "
                  f"{r['jumlah_tiket']:>5} "
                  f"Rp{r['total_harga']:>10,.0f} {r['status']:<8}")
    cetak_garis()
    input("\n  Tekan Enter untuk kembali ke menu...")


# ──────────────────────────────────────────────
# MAIN MENU
# ──────────────────────────────────────────────
def main():
    db.inisialisasi_database()

    while True:
        bersihkan_layar()
        cetak_header()
        print("""
  MENU UTAMA:

  [1]  Lihat Daftar Kereta
  [2]  Pesan Tiket
  [3]  Cek Status Tiket
  [4]  Batalkan Tiket
  [5]  Riwayat Pemesanan
  [0]  Keluar
        """)
        cetak_garis()
        pilihan = input("  Pilih menu: ").strip()

        if   pilihan == "1": tampilkan_daftar_kereta(); input("\n  Tekan Enter...")
        elif pilihan == "2": pesan_tiket()
        elif pilihan == "3": cek_tiket()
        elif pilihan == "4": batalkan_tiket()
        elif pilihan == "5": riwayat_pemesanan()
        elif pilihan == "0":
            print("\n  👋  Terima kasih telah menggunakan layanan KAI. Sampai jumpa!\n")
            sys.exit(0)
        else:
            print("  ⚠  Pilihan tidak valid.")
            input("  Tekan Enter untuk mencoba lagi...")


if __name__ == "__main__":
    main()
