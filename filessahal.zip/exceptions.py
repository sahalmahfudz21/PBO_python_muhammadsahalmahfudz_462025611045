# ============================================================
#   exceptions.py — Custom Exception Classes
#   Sistem Pemesanan Tiket Kereta Api
# ============================================================

class KeretaException(Exception):
    """Base custom exception untuk seluruh aplikasi."""
    def __init__(self, message="Terjadi kesalahan pada sistem kereta."):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f"[KeretaError] {self.message}"


class TiketTidakTersediaException(KeretaException):
    """Raised ketika kursi/tiket tidak tersedia."""
    def __init__(self, kelas, jumlah):
        message = f"Tiket kelas '{kelas}' tidak tersedia untuk {jumlah} penumpang."
        super().__init__(message)


class PembayaranGagalException(KeretaException):
    """Raised ketika pembayaran tidak valid."""
    def __init__(self, jumlah_dibayar, total_tagihan):
        message = (
            f"Pembayaran gagal. Dibayar: Rp{jumlah_dibayar:,.0f}, "
            f"Tagihan: Rp{total_tagihan:,.0f}."
        )
        super().__init__(message)


class PenumpangTidakDitemukanException(KeretaException):
    """Raised ketika data penumpang tidak ditemukan."""
    def __init__(self, nama):
        message = f"Penumpang dengan nama '{nama}' tidak ditemukan dalam sistem."
        super().__init__(message)


class InputTidakValidException(KeretaException):
    """Raised ketika input pengguna tidak valid."""
    def __init__(self, field, nilai):
        message = f"Input tidak valid pada field '{field}': '{nilai}'."
        super().__init__(message)


class KodeBookingTidakDitemukanException(KeretaException):
    """Raised ketika kode booking tidak ada di database."""
    def __init__(self, kode):
        message = f"Kode booking '{kode}' tidak ditemukan."
        super().__init__(message)
